from django.views.generic import View, ListView, CreateView, DetailView, UpdateView
from .models import Project, Task
from .unit import Unidad
from django.http import HttpResponse
import os

class ProjectsList(ListView):
    model=Project

class ProjectsTasksCreate(CreateView):
    model=Task
    fields=('tasktype', 'due_date', 'attached_source', 'project')

class ProjectsTasksList(ListView):
    model=Task
    template_name='tasker/project_task_list.html'

    def get_queryset(self):
        queryset = super(ProjectsTasksList, self).get_queryset()
        return queryset.filter(project=self.args[0])

    def get_context_data(self, **kwargs):
        context = super(ProjectsTasksList, self).get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        context['ppk'] = self.args[0] 
        return context

class TasksAttachmentsCreate(View):
    def get(self, request, *args):
        xml=str(Task.objects.filter(pk__exact=self.args[0])[0].attached_source)
        u = Unidad(xml, 'minsal.xsl')
        fname = u.getZipFileName()
        response = HttpResponse(xml, content_type='octet/plain')
        response['Content-Disposition'] = 'attachment; filename="%s"' % fname
        return HttpResponse(xml)


class TasksResponsiblesUpdate(UpdateView):
    model=Task
    success_url='projects-list'
    fields=['assigned_to',]

#class TasksGenerateProject(View):
#    pass
    #cope(request.filename)
